import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="forest-fire-clusterin-flynn-chen", # Replace with your own username
    version="0.0.1",
    author="Flynn Chen",
    author_email="flynn.chen@yale.edu",
    description="Clustering Method Inspired by Forest Fire Dynamics",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/flynn-chen/forest-fire-clustering.git",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires=[
        'numpy==1.18.1',
        'scipy==1.4.1',
        'scikit-learn==0.22.2.post1'
    ],
    python_requires='>=3.6',
)
